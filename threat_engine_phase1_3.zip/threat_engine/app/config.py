DATABASE_URL = "postgresql://user:pass@localhost/threatdb"
REDIS_URL = "redis://localhost:6379/0"
